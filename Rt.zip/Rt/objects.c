/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   objects.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgaspail <mgaspail@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/03/14 10:26:39 by mgaspail          #+#    #+#             */
/*   Updated: 2014/03/27 21:06:08 by mgaspail         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rt.h"

t_obj	*init_obj(void)
{
	t_obj	*ret;

	if (!(ret = (t_obj*)malloc(sizeof(t_obj))))
		exit(0);
	ret->next = NULL;
	return (ret);
}

void	add_coneinf(double coord[3], double ray, int color[3], t_obj *e)
{
	while (e->next != NULL)
		e = e->next;
	if (!(e->next = (t_obj*)malloc(sizeof(t_obj))))
		exit(0);
	e = e->next;
	e->type = CONEINF;
	e->color[0] = color[0];
	e->color[1] = color[1];
	e->color[2] = color[2];
	e->ambiant = 1;
	e->nbrs[0][X] = coord[X];
	e->nbrs[0][Y] = coord[Y];
	e->nbrs[0][Z] = coord[Z];
	e->nbrs[1][X] = ray;
	e->next = NULL;
}

void	add_cylinf(double coord[3], double ray, int color[3], t_obj *e)
{
	while (e->next != NULL)
		e = e->next;
	if (!(e->next = (t_obj*)malloc(sizeof(t_obj))))
		exit(0);
	e = e->next;
	e->type = CYLINF;
	e->color[0] = color[0];
	e->color[1] = color[1];
	e->color[2] = color[2];
	e->ambiant = 1;
	e->nbrs[0][X] = coord[X];
	e->nbrs[0][Y] = coord[Y];
	e->nbrs[0][Z] = coord[Z];
	e->nbrs[1][X] = ray;
	e->next = NULL;
}

void	add_sphere(double coord[3], double ray, int color[3], t_obj *e)
{
	while (e->next != NULL)
		e = e->next;
	if (!(e->next = (t_obj*)malloc(sizeof(t_obj))))
		exit(0);
	e = e->next;
	e->type = SPHERE;
	e->color[0] = color[0];
	e->color[1] = color[1];
	e->color[2] = color[2];
	e->ambiant = 1;
	e->nbrs[0][X] = coord[X];
	e->nbrs[0][Y] = coord[Y];
	e->nbrs[0][Z] = coord[Z];
	e->nbrs[1][X] = ray;
	e->next = NULL;
}

void	add_plan(double coord[6], double add, int color[3], t_obj *e)
{
	while (e->next != NULL)
		e = e->next;
	if (!(e->next = (t_obj*)malloc(sizeof(t_obj))))
		exit(0);
	e = e->next;
	e->type = PLAN;
	e->color[0] = color[0];
	e->color[1] = color[1];
	e->color[2] = color[2];
	e->ambiant = 1;
	e->nbrs[0][X] = coord[X];
	e->nbrs[0][Y] = coord[Y];
	e->nbrs[0][Z] = coord[Z];
	e->nbrs[1][0] = add;
	e->nbrs[2][X] = coord[3];
	e->nbrs[2][Y] = coord[4];
	e->nbrs[2][Z] = coord[5];
	e->norm[X] = coord[3];
	e->norm[Y] = coord[4];
	e->norm[Z] = coord[5];
	e->next = NULL;
}
