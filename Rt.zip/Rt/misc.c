/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   misc.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgaspail <mgaspail@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/03/26 13:50:29 by mgaspail          #+#    #+#             */
/*   Updated: 2014/03/27 22:25:22 by mgaspail         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rt.h"

double	calc_half_sphere(t_obj *object, t_ray *ray)
{
	double		tmp[4];
	double		ret1;
	double		ret2;

	tmp[A] = pow(ray->dir[X], 2) + pow(ray->dir[Y], 2) + pow(ray->dir[Z], 2);
	tmp[B] = 2 * (ray->dir[X] * (ray->org[X] - object->nbrs[0][X]) +
					ray->dir[Y] * (ray->org[Y] - object->nbrs[0][Y]) +
					ray->dir[Z] * (ray->org[Z] - object->nbrs[0][Z]));
	tmp[C] = (pow(ray->org[X] - object->nbrs[0][X], 2) +
				pow(ray->org[Y] - object->nbrs[0][Y], 2) +
				pow(ray->org[Z] - object->nbrs[0][Z], 2) -
				pow(object->nbrs[1][0], 2));
	tmp[D] = pow(tmp[B], 2) - 4 * tmp[A] * tmp[C];
	if (tmp[D] > 0)
	{
		ret1 = (-tmp[B] + sqrt(tmp[D])) / (2 * tmp[A]);
		ret2 = (-tmp[B] - sqrt(tmp[D])) / (2 * tmp[A]);
		ret1 = (ret1 < ret2 ? ret1 : ret2);
		if (ret1 * ray->dir[Y] + ray->org[Y] <= object->nbrs[0][Y])
			return (ret1);
		if (ret2 * ray->dir[Y] + ray->org[Y] <= object->nbrs[0][Y])
			return (ret2);
	}
	return (-1);
}

void	add_limited_sphere(double coord[3], double ray, int color[3], t_obj *e)
{
	while (e->next != NULL)
		e = e->next;
	if (!(e->next = (t_obj*)malloc(sizeof(t_obj))))
		exit(0);
	e = e->next;
	e->type = HALFSPHERE;
	e->color[0] = color[0];
	e->color[1] = color[1];
	e->color[2] = color[2];
	e->ambiant = 1;
	e->nbrs[0][X] = coord[X];
	e->nbrs[0][Y] = coord[Y];
	e->nbrs[0][Z] = coord[Z];
	e->nbrs[1][X] = ray;
	e->next = NULL;
}

void	ft_free(char **tab)
{
	int		i;

	i = -1;
	while (tab[++i])
		free(tab[i]);
	free(tab);
}
