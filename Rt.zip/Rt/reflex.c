/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   reflex.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgaspail <mgaspail@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/03/26 11:18:04 by mgaspail          #+#    #+#             */
/*   Updated: 2014/03/27 21:34:16 by mgaspail         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rt.h"

double (*g_taba_obj[5])(t_obj*, t_ray*) =
{&calc_sphere, &calc_plan, &calc_cylinf, &calc_coneinf, &calc_half_sphere};

double	get_reflex(double scalval, double norm, double dir)
{
	return (2 * scalval * norm + dir);
}

int		is_lighted(t_obj *check, t_obj *lum, t_stuff *st, t_ray *orgray)
{
	t_ray	ray;
	int		i;
	double	tmp;
	t_obj	*current;
	double	lowestdtr;

	lowestdtr = 10000;
	current = st->objlist->next;
	i = -1;
	while (i++ < 2)
	{
		ray.org[i] = lum->nbrs[0][i];
		ray.dir[i] = get_inter(orgray->org[i], orgray->dir[i], check->dtr) -
			ray.org[i];
	}
	norm_vector(ray.dir);
	while (current)
	{
		if ((tmp = g_taba_obj[current->type - 2](current, &ray)) <= lowestdtr
			&& tmp >= 0)
			lowestdtr = tmp;
		current = current->next;
	}
	return (lowestdtr == g_taba_obj[check->type - 2](check, &ray));
}
