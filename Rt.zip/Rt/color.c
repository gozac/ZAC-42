/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   color.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgaspail <mgaspail@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/03/26 09:49:44 by mgaspail          #+#    #+#             */
/*   Updated: 2014/03/26 09:56:07 by mgaspail         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rt.h"

void		put_px(char *i_data, int color[3])
{
	static char		*read = NULL;

	if (!read)
		read = i_data;
	else
		read++;
	*read++ = color[2];
	*read++ = color[1];
	*read++ = color[0];
}

void		get_object_color(t_stuff *st, t_obj *e)
{
	st->color[0] = e->color[0];
	st->color[1] = e->color[1];
	st->color[2] = e->color[2];
}

void		color_floor1(t_stuff *st, t_obj *e, t_ray *r, double coeff)
{
	if (((int)fabs(floor(r->org[X] + r->dir[X] * coeff)) % 2) ==
		((int)fabs(floor(r->org[Y] + r->dir[Y] * coeff)) % 2))
	{
		st->color[0] = 0x44;
		st->color[1] = 0x44;
		st->color[2] = 0x44;
		light_stuff(e, r, st);
	}
	else
		light_stuff(e, r, st);
}

void		color_floor2(t_stuff *st, t_obj *e, t_ray *r, double coeff)
{
	if (((int)fabs(floor(r->org[X] + r->dir[X] * coeff)) % 2)
		== ((int)fabs(floor(r->org[Y] + r->dir[Y] * coeff)) % 2))
		light_stuff(e, r, st);
	else
	{
		st->color[2] = 0x44;
		st->color[1] = 0x44;
		st->color[0] = 0x44;
		light_stuff(e, r, st);
	}
}

void		get_color(t_stuff *st, t_obj *e, t_ray *r, double coeff)
{
	get_object_color(st, e);
	if (e->type == 10)
	{
		if (((int)fabs(floor(r->org[Z] + r->dir[Z] * coeff)) % 2 == 0))
			color_floor1(st, e, r, coeff);
		else
			color_floor2(st, e, r, coeff);
	}
	light_stuff(e, r, st);
}
