/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rt.h                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgaspail <mgaspail@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/26 16:33:33 by mgaspail          #+#    #+#             */
/*   Updated: 2014/03/27 21:33:52 by mgaspail         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef RT_H
# define RT_H

# include <mlx.h>
# include <math.h>
# include <stdlib.h>
# include <unistd.h>
# include "struct.h"

# define A 0
# define B 1
# define C 2
# define D 3

# define X 0
# define Y 1
# define Z 2

# define CAM 0
# define SPOT 1
# define SPHERE 2
# define PLAN 3
# define CYLINF 4
# define CONEINF 5
# define HALFSPHERE 6

# define AMBLIGHT 0.2
# define DIR(x) (ray->dir[x])
# define OR(x) (ray->org[x])
# define COORDOBJ(x) (object->nbrs[0][x])
# define RSQR (object->nbrs[1][0] * object->nbrs[1][0])

# define RED(x) (x << 16)
# define GREEN(x) (x << 8)
# define BLUE(x) (x << 0)
# define MODRED(x) ((x / 256 / 256))
# define MODGREEN(x) (((x / 256) % 0x100))
# define MODBLUE(x) ((x % 0x100))

# define LARG_VUE 0.5
# define LONG_VUE 0.35
# define DIST_FOC 1

# define SCENE_NB 1

/*
** Init and global
*/

t_obj	*init_obj(void);
void	init_stuff(t_stuff *stuff, char *name);
void	add_cam(double coord[6], t_cam *e);
void	add_sphere(double coord[3], double ray, int color[3], t_obj *e);
void	add_plan(double coord[6], double add, int color[3], t_obj *e);
void	add_cylinf(double coord[3], double ray, int color[3], t_obj *e);
void	add_coneinf(double coord[3], double ray, int color[3], t_obj *e);
void	put_px(char *i_data, int color[3]);
void	norm_vector(double ray[3]);
double	scal_mult(double vec[1], double vec2[2]);
void	ft_init(t_stuff *e, char *name);
void	init_cam(t_stuff *e);
void	ft_free(char **tab);
void	ft_create_scene(t_stuff *e, char *str);
void	get_cam(t_stuff *e, char *str);
void	get_cone(t_stuff *e, char *str);
void	get_half_sphere(t_stuff *e, char *str);
void	add_limited_sphere(double coord[3], double ray, int color[3], t_obj *e);

/*
** Intersection
*/

double	get_inter(double org, double dir, double dtr);
double	get_reflex(double scalval, double norm, double dir);
double	calc_coneinf(t_obj *obj, t_ray *ray);
double	calc_cylinf(t_obj *obj, t_ray *ray);
double	calc_sphere(t_obj *obj, t_ray *ray);
double	calc_plan(t_obj *obj, t_ray *ray);
void	calc_vector(double orig[3], int x, int y, t_stuff *data);
void	norm(double *vector);
void	draw_stuff(t_stuff *data);
void	get_color(t_stuff *st, t_obj *e, t_ray *ray, double coeff);
double	calc_half_sphere(t_obj *object, t_ray *ray);

/*
** LIGHT
*/

void	add_light(t_obj *list, double coord[3], double intens, int color[3]);
void	light_stuff(t_obj *e, t_ray *ray, t_stuff *st);
t_obj	*init_light(void);
int		is_lighted(t_obj *check, t_obj *lum, t_stuff *st, t_ray *orgray);
void	reflex_ly(t_ray *ly, t_obj *e);
void	get_ly(t_ray *ray, t_obj *e, t_obj *list, t_ray *ly);
void	get_norm(t_obj *e, double coord[3]);
t_obj	*init_light(void);

/*
** MLX
*/

int		ft_key_hook(int keycode, t_stuff *e);
int		ft_expose_hook(t_stuff *e);

#endif
