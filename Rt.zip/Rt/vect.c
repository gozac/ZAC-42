/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   vect.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgaspail <mgaspail@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/03/21 12:55:12 by mgaspail          #+#    #+#             */
/*   Updated: 2014/03/27 21:28:54 by mgaspail         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rt.h"

double		get_inter(double org, double dir, double dtr)
{
	return (org + dir * dtr);
}

void		calc_vector(double orig[3], int ind_x, int ind_y, t_stuff *data)
{
	data->ray.org[X] = orig[X];
	data->ray.org[Y] = orig[Y];
	data->ray.org[Z] = orig[Z];
	data->ray.dir[X] = data->cam->upl[X] - data->cam->pos[X] +
		data->cam->left[X] * LARG_VUE / data->x * ind_x -
		data->cam->up[X] * LONG_VUE / data->y * ind_y;
	data->ray.dir[Y] = data->cam->upl[Y] - data->cam->pos[Y] +
		data->cam->left[Y] * LARG_VUE / data->x * ind_x -
		data->cam->up[Y] * LONG_VUE / data->y * ind_y;
	data->ray.dir[Z] = data->cam->upl[Z] - data->cam->pos[Z] +
		data->cam->left[Z] * LARG_VUE / data->x * ind_x -
		data->cam->up[Z] * LONG_VUE / data->y * ind_y;
}

double		scal_mult(double vec1[3], double vec2[3])
{
	return (vec1[X] * vec2[X] + vec1[Y] * vec2[Y] + vec1[Z] * vec2[Z]);
}

void		norm_vector(double *vector)
{
	double	div_vec;

	div_vec = sqrt(scal_mult(vector, vector));
	vector[X] = vector[X] / div_vec;
	vector[Y] = vector[Y] / div_vec;
	vector[Z] = vector[Z] / div_vec;
}
