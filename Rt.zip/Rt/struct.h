/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   struct.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgaspail <mgaspail@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/03/26 12:28:04 by mgaspail          #+#    #+#             */
/*   Updated: 2014/03/27 09:07:18 by mgaspail         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef STRUCT_H
# define STRUCT_H

typedef struct		s_obj
{
	int				type;
	double			nbrs[5][3];
	double			norm[3];
	int				color[3];
	double			ambiant;
	double			dtr;
	struct s_obj	*next;
}					t_obj;

typedef struct		s_cam
{
	double			pos[3];
	double			up[3];
	double			left[3];
	double			upl[3];
	double			dir[3];
}					t_cam;

typedef struct		s_ray
{
	double			org[3];
	double			dir[3];
}					t_ray;

typedef struct		s_stuff
{
	t_cam			*cam;
	int				x;
	int				y;
	t_obj			*objlist;
	void			*mlx;
	t_obj			*lightlist;
	void			*win;
	int				color[3];
	void			*img;
	char			*i_data;
	int				bpp;
	int				size_l;
	int				endian;
	t_ray			ray;
	t_ray			reflex;
}					t_stuff;

#endif
