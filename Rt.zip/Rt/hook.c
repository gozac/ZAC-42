/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hook.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgaspail <mgaspail@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/03/19 16:33:20 by mgaspail          #+#    #+#             */
/*   Updated: 2014/03/26 22:44:44 by mgaspail         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rt.h"

int		ft_key_hook(int keycode, t_stuff *e)
{
	void	*t;

	t = e;
	if (keycode == 65307 && t)
	{
		exit(0);
	}
	return (0);
}

int		ft_expose_hook(t_stuff *e)
{
	int		i;

	i = mlx_put_image_to_window(e->mlx, e->win, e->img, 0, 0);
	return (i);
}
