/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   math.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgaspail <mgaspail@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/03/06 17:44:34 by mgaspail          #+#    #+#             */
/*   Updated: 2014/03/27 20:35:31 by mgaspail         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rt.h"

double		calc_coneinf(t_obj *object, t_ray *ray)
{
	double		tmp[4];
	double		ret1;
	double		ret2;

	tmp[A] = pow(DIR(X), 2) + pow(DIR(Z), 2) - pow(DIR(Y), 2) * RSQR;
	tmp[B] = 2 * (DIR(X) * (OR(X) - COORDOBJ(X)) + DIR(Z) *
					(OR(Z) - COORDOBJ(Z)) + (DIR(Y) * RSQR) *
					(COORDOBJ(Y) - OR(Y)));
	tmp[C] = (pow(OR(X), 2)) + (pow(COORDOBJ(X), 2)) -
		(2 * OR(X) * COORDOBJ(X)) + (pow(OR(Z), 2)) + (pow(COORDOBJ(Z), 2)) -
		(2 * OR(Z) * COORDOBJ(Z)) - (RSQR * pow(OR(Y), 2)) -
		(RSQR * pow(COORDOBJ(Y), 2)) + (RSQR * 2 * OR(Y) * COORDOBJ(Y));
	tmp[D] = pow(tmp[B], 2) - 4 * tmp[A] * tmp[C];
	if (tmp[D] >= 0)
	{
		ret1 = (-tmp[B] + sqrt(tmp[D])) / (2 * tmp[A]);
		ret2 = (-tmp[B] - sqrt(tmp[D])) / (2 * tmp[A]);
		return (ret1 = (ret1 < ret2 ? ret1 : ret2));
	}
	return (-1);
}

double		calc_cylinf(t_obj *object, t_ray *ray)
{
	double	tmp[4];
	double	ret1;
	double	ret2;

	tmp[A] = pow(ray->dir[X], 2) + pow(ray->dir[Z], 2);
	tmp[B] = 2 * (ray->dir[X] * (ray->org[X] - object->nbrs[0][X]) +
				ray->dir[Z] * (ray->org[Z] - object->nbrs[0][Z]));
	tmp[C] = pow(ray->org[X] - object->nbrs[0][X], 2) +
		pow(ray->org[Z] - object->nbrs[0][Z], 2) - pow(object->nbrs[1][X], 2);
	tmp[D] = pow(tmp[B], 2) - 4 * tmp[A] * tmp[C];
	if (tmp[D] >= 0)
	{
		ret1 = (-tmp[B] + sqrt(tmp[D])) / (2 * tmp[A]);
		ret2 = (-tmp[B] - sqrt(tmp[D])) / (2 * tmp[A]);
		return (ret1 = (ret1 < ret2 ? ret1 : ret2));
	}
	return (-1);
}

double		calc_plan(t_obj *object, t_ray *ray)
{
	double		rtn;

	rtn = -((object->nbrs[2][X] * (ray->org[0] - object->nbrs[0][X]) +
					object->nbrs[2][Y] * (ray->org[1] - object->nbrs[0][Y]) +
					object->nbrs[2][Z] * (ray->org[2] - object->nbrs[0][Z]) +
					object->nbrs[1][0]) /
				(object->nbrs[2][X] * ray->dir[X] +
					object->nbrs[2][Y] * ray->dir[Y] +
					object->nbrs[2][Z] * ray->dir[Z]));
	return (rtn);
}

double		calc_sphere(t_obj *object, t_ray *ray)
{
	double	tmp[4];
	double	ret1;
	double	ret2;

	tmp[A] = pow(ray->dir[X], 2) + pow(ray->dir[Y], 2) + pow(ray->dir[Z], 2);
	tmp[B] = 2 * (ray->dir[X] * (ray->org[X] - object->nbrs[0][X]) +
					ray->dir[Y] * (ray->org[Y] - object->nbrs[0][Y]) +
					ray->dir[Z] * (ray->org[Z] - object->nbrs[0][Z]));
	tmp[C] = (pow(ray->org[X] - object->nbrs[0][X], 2) +
				pow(ray->org[Y] - object->nbrs[0][Y], 2) +
				pow(ray->org[Z] - object->nbrs[0][Z], 2) -
				pow(object->nbrs[1][0], 2));
	tmp[D] = pow(tmp[B], 2) - 4 * tmp[A] * tmp[C];
	if (tmp[D] > 0)
	{
		ret1 = (-tmp[B] + sqrt(tmp[D])) / (2 * tmp[A]);
		ret2 = (-tmp[B] - sqrt(tmp[D])) / (2 * tmp[A]);
		return (ret1 = (ret1 < ret2 ? ret1 : ret2));
	}
	return (-1);
}
