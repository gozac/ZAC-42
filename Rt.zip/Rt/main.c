/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgaspail <mgaspail@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/26 16:32:47 by mgaspail          #+#    #+#             */
/*   Updated: 2014/03/27 21:07:33 by mgaspail         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rt.h"
#include "libft/libft.h"

void	init_cam(t_stuff *e)
{
	norm_vector(e->cam->dir);
	e->cam->up[X] = 0;
	e->cam->up[Y] = e->cam->dir[Z];
	e->cam->up[Z] = -e->cam->dir[Y];
	norm_vector(e->cam->up);
	e->cam->left[X] = (e->cam->dir[Y] * e->cam->up[Z]) -
		(e->cam->up[Y] * e->cam->dir[Z]);
	e->cam->left[Y] = (e->cam->dir[Z] * e->cam->up[X]) -
		(e->cam->up[Z] * e->cam->dir[X]);
	e->cam->left[Z] = (e->cam->dir[X] * e->cam->up[Y]) -
		(e->cam->up[X] * e->cam->dir[Y]);
	norm_vector(e->cam->left);
	e->cam->upl[X] = DIST_FOC * e->cam->dir[X] + LONG_VUE * e->cam->up[X] / 2
		- LARG_VUE * e->cam->left[X] / 2 + e->cam->pos[X];
	e->cam->upl[Y] = DIST_FOC * e->cam->dir[Y] + LONG_VUE * e->cam->up[Y] / 2
		- LARG_VUE * e->cam->left[Y] / 2 + e->cam->pos[Y];
	e->cam->upl[Z] = DIST_FOC * e->cam->dir[Z] + LONG_VUE * e->cam->up[Z] / 2
		- LARG_VUE * e->cam->left[Z] / 2 + e->cam->pos[Z];
}

void	init_stuff(t_stuff *e, char *name)
{
	e->x = 800;
	e->y = 600;
	if (!(e->mlx = mlx_init()))
		exit(0);
	e->win = mlx_new_window(e->mlx, e->x, e->y, "HBmgaspail");
	if (!(e->cam = (t_cam*)malloc(sizeof(t_cam))))
		exit(0);
	e->lightlist = init_light();
	e->img = mlx_new_image(e->mlx, e->x, e->y);
	e->i_data = mlx_get_data_addr(e->img, &e->bpp, &e->size_l, &e->endian);
	e->objlist = init_obj();
	ft_init(e, name);
}

void	ft_do_pixel(t_stuff *stuff)
{
	int			ind_x;
	int			ind_y;

	ind_y = -1;
	while (++ind_y < stuff->y)
	{
		ind_x = -1;
		while (++ind_x < stuff->x)
		{
			calc_vector(stuff->cam->pos, ind_x, ind_y, stuff);
			draw_stuff(stuff);
			put_px(stuff->i_data, stuff->color);
		}
	}
}

int		main(int argc, char **argv)
{
	t_stuff		stuff;

	if (argc == 2)
	{
		init_stuff(&stuff, argv[1]);
		ft_do_pixel(&stuff);
		mlx_put_image_to_window(stuff.mlx, stuff.win, stuff.img, 0, 0);
		mlx_expose_hook(stuff.win, ft_expose_hook, &stuff);
		mlx_key_hook(stuff.win, ft_key_hook, &stuff);
		mlx_loop(stuff.mlx);
	}
	else
		ft_putendl("usage : ./rt scene");
	return (0);
}
