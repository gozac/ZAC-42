/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   light.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgaspail <mgaspail@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/03/26 10:02:26 by mgaspail          #+#    #+#             */
/*   Updated: 2014/03/27 19:24:03 by mgaspail         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rt.h"

void	norm_color(t_stuff *st, double *colors)
{
	int		i;

	i = -1;
	while (++i < 3)
		st->color[i] = floor(colors[i]) > 255 ? 255 : floor(colors[i]);
	free(colors);
}

void	init_color(t_stuff *st, double *colors)
{
	int		i;

	i = -1;
	while (++i < 3)
		colors[i] = (double)st->color[i] * AMBLIGHT;
}

void	tmp_color(t_stuff *st, t_obj *e, t_ray *ly, double *colors)
{
	int		i;
	double	tmp;

	i = -1;
	while (++i < 3)
	{
		tmp = ((double)st->color[i] * scal_mult(ly->dir, e->norm) * 0.7);
		colors[i] = (!tmp ? colors[i] : colors[i] + tmp);
		colors[i] = (colors[i] < 0 ? 0 : colors[i]);
	}
}

void	color_reflex(t_obj *e, t_ray *ly, double *colors, int lum_col[3])
{
	int		i;
	double	tmp;

	i = -1;
	while (++i < 3)
	{
		tmp = (0.85 * lum_col[i] * pow(scal_mult(ly->dir, e->norm), 75));
		colors[i] = (tmp < 0 ? colors[i] : colors[i] + tmp);
		colors[i] = (colors[i] < 0 ? 0 : colors[i]);
	}
}

void	light_stuff(t_obj *e, t_ray *ray, t_stuff *st)
{
	double	*colors;
	double	coord[3];
	t_ray	ly;
	t_obj	*list;

	if ((colors = (double *)malloc(sizeof(double) * 3)) == NULL)
		return ;
	init_color(st, colors);
	list = st->lightlist->next;
	while (list != NULL)
	{
		if (is_lighted(e, list, st, ray))
		{
			get_ly(ray, e, list, &ly);
			coord[0] = get_inter(ray->org[0], ray->dir[0], e->dtr);
			coord[1] = get_inter(ray->org[1], ray->dir[1], e->dtr);
			coord[2] = get_inter(ray->org[2], ray->dir[2], e->dtr);
			get_norm(e, coord);
			tmp_color(st, e, &ly, colors);
			reflex_ly(&ly, e);
			color_reflex(e, &ly, colors, list->color);
		}
		list = list->next;
	}
	norm_color(st, colors);
}
