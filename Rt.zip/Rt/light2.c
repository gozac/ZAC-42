/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   light2.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgaspail <mgaspail@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/03/26 11:46:34 by mgaspail          #+#    #+#             */
/*   Updated: 2014/03/27 22:03:12 by mgaspail         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rt.h"

t_obj		*init_light(void)
{
	t_obj		*light;

	if (!(light = (t_obj*)malloc(sizeof(t_obj))))
		exit(0);
	light->next = NULL;
	return (light);
}

void		add_light(t_obj *list, double coord[3], double intens, int color[3])
{
	while (list->next != NULL)
		list = list->next;
	if (!(list->next = (t_obj*)malloc(sizeof(t_obj))))
		exit(0);
	list = list->next;
	list->nbrs[0][X] = coord[X];
	list->nbrs[0][Y] = coord[Y];
	list->nbrs[0][Z] = coord[Z];
	list->color[0] = color[0];
	list->color[1] = color[1];
	list->color[2] = color[2];
	list->nbrs[1][0] = intens;
	list->next = NULL;
}

void		get_norm(t_obj *e, double coord[3])
{
	if (e->type == SPHERE || e->type == HALFSPHERE)
	{
		e->norm[0] = coord[0] - e->nbrs[0][0];
		e->norm[1] = coord[1] - e->nbrs[0][1];
		e->norm[2] = coord[2] - e->nbrs[0][2];
	}
	if (e->type == CYLINF)
	{
		e->norm[0] = coord[0] - e->nbrs[0][0];
		e->norm[1] = 0;
		e->norm[2] = coord[2] - e->nbrs[0][2];
	}
	if (e->type == CONEINF)
	{
		e->norm[0] = coord[0] - (-e->nbrs[1][0] * (coord[0] - e->nbrs[0][0]) +
					coord[0]);
		e->norm[1] = coord[1] - (-e->nbrs[1][0] * (coord[1] - e->nbrs[0][1]) +
					coord[1]);
		e->norm[2] = coord[2] - (-e->nbrs[1][0] * (coord[2] - e->nbrs[0][2]) +
					coord[2]);
	}
	norm_vector(e->norm);
}

void		get_ly(t_ray *ray, t_obj *e, t_obj *list, t_ray *ly)
{
	int		i;

	i = -1;
	while (++i < 3)
		ly->org[i] = list->nbrs[0][i];
	i = -1;
	while (++i < 3)
	{
		ly->dir[i] = list->nbrs[0][i] -
			get_inter(ray->org[i], ray->dir[i], e->dtr);
	}
	norm_vector(ly->dir);
}

void		reflex_ly(t_ray *ly, t_obj *e)
{
	int		i;

	i = -1;
	while (++i < 3)
	{
		ly->dir[i] = get_reflex(scal_mult(ly->dir, e->norm),
								e->norm[i], ly->dir[i]);
	}
	norm_vector(ly->dir);
}
