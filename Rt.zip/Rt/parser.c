/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parser.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgaspail <mgaspail@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/26 16:32:39 by mgaspail          #+#    #+#             */
/*   Updated: 2014/03/27 22:08:20 by mgaspail         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rt.h"
#include "libft/libft.h"

void	get_cyl(t_stuff *e, char *str)
{
	double		coord[6];
	char		**tab;
	double		ray;
	int			color[3];

	tab = ft_strsplit(str, '\t');
	if (!tab[6])
		exit(0);
	coord[X] = atof(tab[X]);
	coord[Y] = atof(tab[Y]);
	coord[Z] = atof(tab[Z]);
	ray = atof(tab[3]);
	color[0] = ft_atoi(tab[4]);
	color[1] = ft_atoi(tab[5]);
	color[2] = ft_atoi(tab[6]);
	coord[3] = atof(tab[7]);
	coord[4] = atof(tab[8]);
	coord[5] = atof(tab[9]);
	add_cylinf(coord, ray, color, e->objlist);
	ft_free(tab);
}

void	get_sphere(t_stuff *e, char *str)
{
	double		coord[3];
	char		**tab;
	double		ray;
	int			color[3];

	tab = ft_strsplit(str, '\t');
	if (!tab[6])
		exit(0);
	coord[X] = atof(tab[X]);
	coord[Y] = atof(tab[Y]);
	coord[Z] = atof(tab[Z]);
	ray = atof(tab[3]);
	color[0] = ft_atoi(tab[4]);
	color[1] = ft_atoi(tab[5]);
	color[2] = ft_atoi(tab[6]);
	add_sphere(coord, ray, color, e->objlist);
	ft_free(tab);
}

void	get_plane(t_stuff *e, char *str)
{
	double	coord[6];
	int		color[3];
	double	add;
	char	**tab;

	tab = ft_strsplit(str, '\t');
	if (!tab[9])
		exit(0);
	coord[X] = atof(tab[X]);
	coord[Y] = atof(tab[Y]);
	coord[Z] = atof(tab[Z]);
	coord[3] = atof(tab[3]);
	coord[4] = atof(tab[4]);
	coord[5] = atof(tab[5]);
	color[0] = ft_atoi(tab[6]);
	color[1] = ft_atoi(tab[7]);
	color[2] = ft_atoi(tab[8]);
	add = atof(tab[9]);
	add_plan(coord, add, color, e->objlist);
	ft_free(tab);
}

void	get_light(t_stuff *e, char *str)
{
	char	**tab;
	double	coord[3];
	double	intensity;
	int		color[3];

	tab = ft_strsplit(str, '\t');
	if (!tab[6])
		exit(0);
	coord[X] = atof(tab[X]);
	coord[Y] = atof(tab[Y]);
	coord[Z] = atof(tab[Z]);
	color[0] = ft_atoi(tab[3]);
	color[1] = ft_atoi(tab[4]);
	color[2] = ft_atoi(tab[5]);
	intensity = atof(tab[6]);
	add_light(e->lightlist, coord, intensity, color);
	ft_free(tab);
}

void	ft_create_scene(t_stuff *e, char *str)
{
	char	**tab;
	int		i;

	tab = ft_strsplit(str, '\n');
	i = -1;
	while (tab[++i])
	{
		if (tab[i][1] == 'a' && tab[i + 2])
			get_cam(e, tab[i + 2]);
		else if (tab[i][0] == 'S' && tab[i + 2])
			get_sphere(e, tab[i + 2]);
		else if (tab[i][1] == 'y' && tab[i + 2])
			get_cyl(e, tab[i + 2]);
		else if (tab[i][0] == 'P' && tab[i + 2])
			get_plane(e, tab[i + 2]);
		else if (tab[i][1] == 'o' && tab[i + 2])
			get_cone(e, tab[i + 2]);
		else if (tab[i][0] == 'L' && tab[i + 2])
			get_light(e, tab[i + 2]);
		else if (tab[i][0] == 'H' && tab[i + 2])
			get_half_sphere(e, tab[i + 2]);
	}
	ft_free(tab);
}
