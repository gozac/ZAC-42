/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   draw.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgaspail <mgaspail@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/03/26 09:57:23 by mgaspail          #+#    #+#             */
/*   Updated: 2014/03/27 21:44:00 by mgaspail         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rt.h"

double (*g_tab_obj[5])(t_obj*, t_ray*) =
{&calc_sphere, &calc_plan, &calc_cylinf, &calc_coneinf, &calc_half_sphere};

void	draw_stuff(t_stuff *e)
{
	double		lowestdtr;
	t_obj		*current;

	current = e->objlist->next;
	lowestdtr = 1000000;
	e->color[0] = 0;
	e->color[1] = 0;
	e->color[2] = 0;
	while (current != NULL)
	{
		current->dtr = g_tab_obj[current->type - 2](current, &e->ray);
		if (current->dtr < lowestdtr && current->dtr >= 0)
		{
			lowestdtr = current->dtr;
			get_color(e, current, &e->ray, current->dtr);
		}
		current = current->next;
	}
}
