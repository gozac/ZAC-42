/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parser2.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgaspail <mgaspail@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/03/27 11:14:24 by mgaspail          #+#    #+#             */
/*   Updated: 2014/03/27 21:59:53 by mgaspail         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rt.h"
#include <fcntl.h>
#include "libft/libft.h"

void	add_cam(double coord[6], t_cam *e)
{
	e->pos[X] = coord[X];
	e->pos[Y] = coord[Y];
	e->pos[Z] = coord[Z];
	e->dir[X] = coord[3];
	e->dir[Y] = coord[4];
	e->dir[Z] = coord[5];
}

void	get_cam(t_stuff *e, char *str)
{
	double		coord[6];
	char		**tab;

	tab = ft_strsplit(str, '\t');
	if (!tab[5])
		exit(0);
	coord[X] = atof(tab[X]);
	coord[Y] = atof(tab[Y]);
	coord[Z] = atof(tab[Z]);
	coord[3] = atof(tab[3]);
	coord[4] = atof(tab[4]);
	coord[5] = atof(tab[5]);
	add_cam(coord, e->cam);
	ft_free(tab);
}

void	get_cone(t_stuff *e, char *str)
{
	double		coord[6];
	char		**tab;
	double		ray;
	int			color[3];

	tab = ft_strsplit(str, '\t');
	if (!tab[6])
		exit(0);
	coord[X] = atof(tab[X]);
	coord[Y] = atof(tab[Y]);
	coord[Z] = atof(tab[Z]);
	ray = atof(tab[3]);
	color[0] = ft_atoi(tab[4]);
	color[1] = ft_atoi(tab[5]);
	color[2] = ft_atoi(tab[6]);
	coord[3] = atof(tab[7]);
	coord[4] = atof(tab[8]);
	coord[5] = atof(tab[9]);
	add_coneinf(coord, ray, color, e->objlist);
	ft_free(tab);
}

void	get_half_sphere(t_stuff *e, char *str)
{
	double		coord[3];
	char		**tab;
	double		ray;
	int			color[3];

	tab = ft_strsplit(str, '\t');
	if (!tab[6])
		exit(0);
	coord[X] = atof(tab[X]);
	coord[Y] = atof(tab[Y]);
	coord[Z] = atof(tab[Z]);
	ray = atof(tab[3]);
	color[0] = ft_atoi(tab[4]);
	color[1] = ft_atoi(tab[5]);
	color[2] = ft_atoi(tab[6]);
	add_limited_sphere(coord, ray, color, e->objlist);
	ft_free(tab);
}

void	ft_init(t_stuff *e, char *name)
{
	int		fd;
	char	*str;

	if ((fd = open(name, O_RDONLY)) == -1)
		exit(0);
	ft_read_file(fd, &str);
	ft_create_scene(e, str);
	if (close(fd) == -1)
		exit(0);
	init_cam(e);
	free(str);
}
