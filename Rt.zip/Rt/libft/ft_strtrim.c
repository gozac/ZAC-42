/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strtrim.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgaspail <mgaspail@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/22 17:57:32 by mgaspail          #+#    #+#             */
/*   Updated: 2014/03/26 12:11:34 by mgaspail         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "libft.h"
#include <string.h>

char	*ft_strtrim(char const *s)
{
	char	*str;
	int		i;
	int		len;
	int		j;

	i = 0;
	j = 0;
	if (!s)
		return (NULL);
	str = ft_memalloc(ft_strlen((char*)s));
	if (!str)
		return (NULL);
	while (s[i] == ' ' || s[i] == '\n' || s[i] == '\t')
		j += 1 + 0 * (i += 1);
	str = ft_strcpy(str, s + i);
	len = ft_strlen(str);
	i = 1;
	while (str[len - i] == ' ' || str[len - i] == '\n'
			|| str[len - i] == '\t')
	{
		str[len - i] = '\0';
		j += 1 + 0 * (i += 1);
	}
	return (str);
}
